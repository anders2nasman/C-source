#include "model.h"
#include "view.h"

int main()
{
	Model model;
	View view;
	char c;
	pair<string,string> data;
	string s;
	bool result;

	do
	{
		view.present("\n\n\tMenu:\n\n");
		view.present("\t1.\tAdd to database\n");
		view.present("\t2.\tLookup\n");
		view.present("\t3.\tReverse lookup\n");
		view.present("\t4.\tDump database\n");
		view.present("\t5.\tDelete entry\n");
		view.present("\tq.\tQuit\n\n\t");

		do
		{
			c = view.getchar();
		} while (c == '\n');
		view.getchar();
		view.present("\n");

		switch (c)
		{
		case '1':

			break;
		case '2':

			break;
		case '3':

			break;
		case '4':

			break;
		case '5':

		}
	} while (!((c == 'q') || (c == 'Q')));

	return 0;
}
