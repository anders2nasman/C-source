#include "model.h"

void Model::write(const pair<string, string>& data)
{

}

bool Model::get(const string& key, string& value)
{

}

bool Model::search(const string& value)
{

}

bool Model::next(pair<string, string>& data, const string& value)
{

}

bool Model::dump()
{

}

bool Model::next(pair<string, string>& data)
{

}

bool Model::erase(const string& key)
{

}
