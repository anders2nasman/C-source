#include "view.h"

void View::present(const string& text)
{

}

char View::getchar()
{

}

pair<string, string> View::getdata()
{
	pair<string, string> input;
	string line;
	getline(cin, line);
	stringstream ss(line);
	ss >> input.first >> input.second;
	return input;
}

string View::getstring()
{

}
